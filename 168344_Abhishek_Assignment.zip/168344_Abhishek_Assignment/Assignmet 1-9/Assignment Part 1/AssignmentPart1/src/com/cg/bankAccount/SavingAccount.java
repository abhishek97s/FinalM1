package com.cg.bankAccount;

public class SavingAccount extends Account{
	final double minimumBalance=500.00;
	@Override
	void withdraw(double amount) {
		super.withdraw(amount);
		if(this.balance - amount>=minimumBalance)
			this.balance -=amount;
		else
			System.out.println("Low balance");
			System.out.println("You should have at least Rs."+minimumBalance);
	}
}
