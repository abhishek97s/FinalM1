package com.cg.stringoperations;

import java.util.Arrays;
public class StringOperations {
	String str;
	int asciiCurrent,asciiPrevious;
	public String concat(String str) {		
		return str+str;
	}
	public String replaceOdd(String str) {
		String str1="";											
		for(int i =0;i<str.length();i++) {
			if(i%2 ==0)
				str1+=str.charAt(i);			
			else
				str1+="#";						
		}
		return str1;
	}
	public String removeDuplicate(String str) {
		char[] characters = str.toCharArray();
		boolean[] found = new boolean[256];
		StringBuilder sb = new StringBuilder();
		for (char c : characters) {
			if (!found[c]) {
			    found[c] = true;
			    sb.append(c);
			}
		}
		return sb.toString();
	}
	public String oddUpper(String str) {
		String str1 ="";
		for(int i=0;i<str.length();i++)
			if(i%2==0)
				str1+=str.charAt(i);
			else
				str1+=Character.toUpperCase(str.charAt(i));
		return str1;
	}
	public boolean checkPositiveString(String str) {
		for(int i = 0;i<str.length();i++) {
			asciiCurrent =str.charAt(i); 
			if(asciiPrevious > asciiCurrent)
				return false;
		}
		return true;
	}
	public String[] sortArray(String[] str) {
		Arrays.sort(str);
		int n=str.length%2;
		n=str.length%2==0?(n/2):(n/2)+1;
		int i = 0;
		while(i<str.length) {
			if(i<=n)
				str[i].toUpperCase();
			else
				str[i].toLowerCase();
		}
		return str;
	}
	public boolean validateString(String str) {
		if(str.endsWith("_job") && str.length()>=8)
			return true;
		return false;
	}
	public static void main(String[] aa) {
		StringOperations op = new StringOperations();
		System.out.println(op.removeDuplicate("tanuj kumar"));	
	}
}
