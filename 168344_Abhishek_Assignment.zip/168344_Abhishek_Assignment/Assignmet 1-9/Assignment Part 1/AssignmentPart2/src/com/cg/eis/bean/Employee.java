package com.cg.eis.bean;

public class Employee {
	int id, salary,previousClaim;
	String name, designation,insuranceScheme;
	boolean previousInsurance;
	public Employee() {
		super();
	}
	public Employee(int id, int salary, String name, String designation,boolean previousInsurance,int previousClaim) {
		super();
		this.id = id;
		this.salary = salary;
		this.name = name;
		this.designation = designation;
		this.previousInsurance=previousInsurance;
		this.previousClaim=previousClaim;
	}
	public Employee(int id, int salary, String insuranceScheme, String name, String designation) {
		super();
		this.id = id;
		this.salary = salary;
		this.insuranceScheme = insuranceScheme;
		this.name = name;
		this.designation = designation;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPreviousClaim() {
		return previousClaim;
	}
	public int setPreviousClaim(int previousClaim) {
		return this.previousClaim = previousClaim;
		
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	public String getName() {
		return name;
	}
	public boolean isPreviousInsurance() {
		return previousInsurance;
	}
	public void setPreviousInsurance(boolean previousInsurance) {
		this.previousInsurance = previousInsurance;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((designation == null) ? 0 : designation.hashCode());
		result = prime * result + id;
		result = prime * result + ((insuranceScheme == null) ? 0 : insuranceScheme.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + salary;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		if (id != other.id)
			return false;
		if (insuranceScheme == null) {
			if (other.insuranceScheme != null)
				return false;
		} else if (!insuranceScheme.equals(other.insuranceScheme))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (salary != other.salary)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + ", insuranceScheme=" + insuranceScheme + ", name=" + name
				+ ", designation=" + designation + "]";
	}
}
